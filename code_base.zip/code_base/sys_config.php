<?php
	$mysql_host = '';
	$mysql_user = '';
	$mysql_pass = '';
	$mysql_db	= '';
	
	mysql_connect($mysql_host, $mysql_user, $mysql_pass);
	mysql_select_db($mysql_db);
?>
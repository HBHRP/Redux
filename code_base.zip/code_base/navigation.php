<table width=100%>
  <tr>
    <td class="navigation">
      <a class="navigation" href="index.php?link=home">Home</a>
    </td>
  </tr>
  <tr>
    <td class="navigation">
      <a class="navigation" href="index.php?link=news">News</a>
    </td>
  </tr>
  <tr>
    <td class="navigation">
      <a class="navigation" href="index.php?link=membership">Membership</a>
    </td>
  </tr>
  <tr>
    <td class="navigation">
      <a class="navigation" href="index.php?link=members">Members</a>
    </td>
  </tr>
  <tr>
    <td class="navigation">
      <a class="navigation" href="index.php?link=contact">Contact Us</a>
    </td>
  </tr>

</table>